#!/system/bin/sh
MODDIR=${0%/*}

insmod=$MODDIR/bin/insmod2
module=$MODDIR/vendor/lib/modules/md_patcher.ko

chmod +x $insmod
$insmod $module || $insmod -f $module || insmod $module
