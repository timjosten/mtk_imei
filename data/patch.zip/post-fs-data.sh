#!/system/bin/sh
MODDIR=${0%/*}

insmod $MODDIR/vendor/lib/modules/md_patcher.ko
