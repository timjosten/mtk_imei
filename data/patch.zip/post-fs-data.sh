#!/system/bin/sh
MODDIR=${0%/*}

module=$MODDIR/vendor/lib/modules/md_patcher.ko
if [ -f $module ]; then
  insmod=$MODDIR/bin/insmod2
  chmod +x $insmod
  $insmod $module || $insmod -f $module || insmod $module
else
  chmod +x $MODDIR/bin/resetprop
  $MODDIR/bin/resetprop ro.boot.hwlevel P0
fi
